"use client";

import React from "react";
import { Toaster } from "react-hot-toast";

const CommonClient = () => {
  return (
    <>
      <Toaster />
    </>
  );
};

export default CommonClient;
