export const data={
   
        "product_id": 16,
        "name": "saree",
        "description": "saree",
        "category_id": 4,
        "price": "2000.00",
        "discount_percentage": 10,
       
        "color": "pink",
        "image1": "1691856355942-WhatsApp Image 2023-08-12 at 03.46.03.jpeg",
        "image2": "1691856355943-WhatsApp Image 2023-08-12 at 03.46.03.jpeg",
        "image3": "1691856355945-WhatsApp Image 2023-08-12 at 03.46.03.jpeg",
        "color_hex": "#d091e3",
       
        "new_varient_s": [
            {
                "variant_id": 8,
                "product_id": 16,
                "color": "red",
               
                "image1": "1692032789663-52 (1).jpg",
                "image2": "1692032789674-52 (2).jpg",
                "image3": "1692032789691-52 (3).jpg",
                "color_hex": "#831100",
             
            },
            {
                "variant_id": 9,
                "product_id": 16,
                "color": "pink",
                "size": null,
                "image1": "1692032834311-07009 (3).JPG",
                "image2": "1692032834320-07009 (4).JPG",
                "image3": "1692032834323-07009 (6).JPG",
                "color_hex": "#be38f3",
               
            }
        ]
    }
   
