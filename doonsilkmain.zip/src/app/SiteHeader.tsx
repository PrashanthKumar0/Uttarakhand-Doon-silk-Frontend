"use client";

import React from "react";


import HeaderLogged from "@/components/Header/HeaderLogged";

const SiteHeader = () => {
 
 // let pathname = usePathname();

  return  <HeaderLogged />;
};

export default SiteHeader;
