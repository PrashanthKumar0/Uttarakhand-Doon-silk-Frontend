// export const baseUrl= 'http://52.66.55.10'
// export const baseImgUrl='http://52.66.55.10/public/image/'

export const baseUrl= "http://localhost:8000"
export const baseImgUrl='http://localhost:8000/public/image/'